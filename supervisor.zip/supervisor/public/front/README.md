# Azzara Admin Dashboard Template

![](http://themekita.com/assets/images/azzarathumb.png)

Free Bootstrap 4 Admin Dashboard

Azzara is a beautiful and elegant Bootstrap 4 admin dashboard designed to manage and visualize data about your business. It combines easy colors on the eyes, wide cards, beautiful typography, and graphics.

For plugin options, we are very selective in choosing. We only use plugins that are really needed to maintain templates quickly and lightly.

We make documentation how you start using this dashboard template and use available components and plugins.

Let us know what you think and what we can improve below. And good luck with development!
