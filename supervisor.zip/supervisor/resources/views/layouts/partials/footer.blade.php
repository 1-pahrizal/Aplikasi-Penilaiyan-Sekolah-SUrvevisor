 <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Project By &hearts; <a href="https://github.com/rizalihwan" target="_blank"> Rizalihwan</a></span>
          </div>
        </div>
      </footer>
<!-- End of Footer -->
