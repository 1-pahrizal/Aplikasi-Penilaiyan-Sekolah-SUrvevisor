<?php $__env->startSection('content'); ?>
    <div class="wrapper wrapper-login">
		<div class="container container-login animated fadeIn">
			<h3 class="text-center">App|Suvervisor</h3>
            <div class="login-form">
                <form action="<?php echo e(route('login')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group form-floating-label">
                        <input id="username" name="email" type="email" class="form-control input-border-bottom" value="<?php echo e(old('email')); ?>" autofocus required>
                        <label for="username" class="placeholder">Email</label>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group form-floating-label">
                        <input id="password" name="password" type="password" class="form-control input-border-bottom" required>
                        <label for="password" class="placeholder">Password</label>
                        <div class="show-password">
                            <i class="flaticon-interface"></i>
                        </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="row form-sub m-0">
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="rememberme" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            <label class="custom-control-label" for="rememberme">Remember Me</label>
                        </div>
                    </div>
                    <div class="form-action mb-2">
                        <button type="submit" class="btn btn-primary btn-rounded btn-login">Login</button>
                    </div>
                    <div class="form-action mb-5">
                        <?php if(Route::has('register')): ?>
                            Tidak Punya akun ? <a href="<?php echo e(route('register')); ?>">Daftar disini</a>
                        <?php endif; ?>
                    </div>
                </form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.loglayout', ['title' => 'LoginSuvervisor'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supervisor\resources\views/auth/login.blade.php ENDPATH**/ ?>