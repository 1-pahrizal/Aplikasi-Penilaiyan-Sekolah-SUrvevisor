<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Content Row -->
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="table-responsive">
                    <table class="table table-light">
                        <tr style="background: gray; color: #ffffff;">
                            <th>#</th>
                            <th>Nama Guru</th>
                            <th>Materi</th>
                            <th>Status</th>
                            <th>Diunggah Pada</th>
                            <th>Action</th>
                        </tr>
                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration + $data->firstItem() - 1 . '.'); ?></td>
                                <td><?php echo e($row->nama_guru); ?></td>
                                <td><a href="<?php echo e(asset('files/' . $row->file)); ?>" rel="noopener noreferrer" target="_blank">Lihat Materi</a></td>
                                <td>
                                    <?php if($row->status == 0): ?>
                                        <span class="badge badge-danger"><?php echo e('Belum Dikonfirmasi'); ?></span>
                                    <?php endif; ?>
                                    <?php if($row->status == 1): ?>
                                        <span class="badge badge-success"><?php echo e('Lulus Penilaian'); ?></span>
                                    <?php endif; ?>
                                    <?php if($row->status == 2): ?>
                                        <span class="badge badge-warning"><?php echo e('Belum Lulus'); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($row->created_at->format('d F, Y') . ' ' . $row->created_at->diffForHumans()); ?></td>
                                <td><a href="<?php echo e(route('supervisor.edit', $row->id)); ?>">Beri Nilai</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-danger text-center">Data Kosong!</td>
                            </tr>
                        <?php endif; ?>
                    </table>
                </div>
            </div>
            <div class="card-footer">
                <?php echo e($data->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'PageSupervisor'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supervisor\resources\views/supervisor/index.blade.php ENDPATH**/ ?>