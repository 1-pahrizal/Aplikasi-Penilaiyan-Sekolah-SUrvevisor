<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Content Row -->
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <form action="<?php echo e(route('supervisor.update', $data->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="col-sm-12">
                        <div class="form-group">
                            <input type="hidden" name="nama_guru" value="<?php echo e($data->nama_guru); ?>">
                            <input type="hidden" name="mapel" value="<?php echo e($data->mapel); ?>">
                            <input type="hidden" name="file" value="<?php echo e($data->file); ?>">
                            <br/>
                            <label for="stat">Keputusan Penilaian untuk guru : <?php echo e($data->nama_guru); ?></label>
                            <select name="status" id="stat" class="form-control">
                                <option value="0">Belum Dikonfirmasi</option>
                                <option value="1">Lulus Penilaian</option>
                                <option value="2">Tidak Lulus</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-success mr-1">Kirim</button>
                            <a href="<?php echo e(route('supervisor.index')); ?>" class="btn btn-danger">Back</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'PageSupervisor'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\supervisor\resources\views/supervisor/edit.blade.php ENDPATH**/ ?>