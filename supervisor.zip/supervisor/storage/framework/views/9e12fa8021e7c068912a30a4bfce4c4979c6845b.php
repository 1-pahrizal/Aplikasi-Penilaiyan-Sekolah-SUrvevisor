<!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

<?php /**PATH C:\xampp\htdocs\supervisor\resources\views/layouts/partials/scrool-btn.blade.php ENDPATH**/ ?>